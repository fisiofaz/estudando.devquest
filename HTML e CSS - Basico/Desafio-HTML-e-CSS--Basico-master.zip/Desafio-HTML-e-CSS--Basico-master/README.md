# Desafio-HTML-e-CSS-Basico

Um Desafio realizado para treinamewnto de HTML e CSS basico durante as aulas da DEVQUEST.

## Tecnologias Utilizadas nesse desafio:

- HTML
- CSS

## Desenvolvido por quem:

Fabio André Zatta - @fabio_zatta
